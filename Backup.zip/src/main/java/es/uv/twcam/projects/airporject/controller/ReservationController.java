package es.uv.twcam.projects.airporject.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import es.uv.twcam.projects.airporject.requestDTO.PassengerRequestDTO;
import es.uv.twcam.projects.airporject.requestDTO.ReservationRequestDTO;
import es.uv.twcam.projects.airproject.EntityException.FlightNotFoundException;
import es.uv.twcam.projects.airproject.EntityException.PersonNotFoundException;
import es.uv.twcam.projects.airproject.entity.Flight;
import es.uv.twcam.projects.airproject.entity.FlightReservation;
import es.uv.twcam.projects.airproject.entity.FlightReservation.Status;
import es.uv.twcam.projects.airproject.entity.PassegerReservation;
import es.uv.twcam.projects.airproject.entity.Person;
import es.uv.twcam.projects.airproject.entity.Reservation;
import es.uv.twcam.projects.airproject.entity.Reservation.ReservationType;
import es.uv.twcam.projects.airproject.entity.Seat;
import es.uv.twcam.projects.airproject.repositoryDAO.DataDAOFactory;
import es.uv.twcam.projects.airproject.repositoryDAO.DataDAOFactory.TYPE;
import es.uv.twcam.projects.airproject.service.IFlightDAO;
import es.uv.twcam.projects.airproject.service.IPersonDAO;
import es.uv.twcam.projects.airproject.service.IReservationDAO;
import es.uv.twcam.projects.airproject.service.ISeatDAO;

@RestController
@RequestMapping("/api/reservations")
public class ReservationController {

	private IFlightDAO flightService;
	private IReservationDAO reservationService;
	private IPersonDAO personService;
	private ISeatDAO seatService;

	public ReservationController() {
		DataDAOFactory factory = DataDAOFactory.getDAOFactory(TYPE.JPA);
		flightService = factory.getFlightDAO();
		reservationService = factory.getReservationDAO();
		personService = factory.getPersonDAO();

	}

	@PostMapping
	public ResponseEntity<Reservation> createReservation(@RequestBody ReservationRequestDTO reservationDTO) {

		Flight flight = flightService.getFlight(reservationDTO.getIdFlight());

		int numberSeats = reservationDTO.getPassengers().size();
		int numberBaggage = 0;
		int numberPriority = 0;

		if (flight == null)
			throw new FlightNotFoundException();

		if (flight.getAvailableSeats() < numberSeats)
			throw new SeatsNotAvailableException("El número de asientos no esta disponible");

		List<PassegerReservation> passengers = new ArrayList<PassegerReservation>();
		Person customer = null;
		Person passenger;

		for (PassengerRequestDTO pas : reservationDTO.getPassengers()) {
			passenger = getOrCreatePassenger(pas);
			if (pas.getDni().equals(reservationDTO.getDniCustomer()))
				customer = Person.copyPerson(passenger);
			passengers.add(new PassegerReservation(passenger, pas.isPrioritario(), false));

			if (pas.isPrioritario())
				numberPriority++;
			numberBaggage += pas.getEquipaje();
			reservationSeat(flight.getSeats(), pas.getAsiento());

		}

		List<FlightReservation> flights = new ArrayList<FlightReservation>();
		
		flights.add(new FlightReservation(flight, Status.scheduled));

		Reservation newReservation = new Reservation(ReservationType.one, numberBaggage, numberPriority, customer,
				flights, passengers);
		reservationService.createReservation(newReservation);
		return new ResponseEntity<Reservation>(newReservation, HttpStatus.CREATED);
	}

	private Person getOrCreatePassenger(PassengerRequestDTO passenger) {
		Person person;
		try {
			person = personService.findPersonByDNI(passenger.getDni());
		} catch (PersonNotFoundException e) {
			System.out.println(e.getMessage());
			person = new Person(passenger.getDni(), passenger.getNombre(), passenger.getApellido());
			personService.createPerson(person);
		}
		return person;

	}

	private void reservationSeat(List<Seat> seats, String asiento) {
		for (Seat s : seats) {
			if (s.getCode().equals(asiento)) {
				s.setAvailable(false);
				seatService.updateSeat(s);
				break;
			}
		}
	}
	private void generatePago() {
		
	}

}
