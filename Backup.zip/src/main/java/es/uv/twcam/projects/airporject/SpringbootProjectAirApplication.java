package es.uv.twcam.projects.airporject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootProjectAirApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootProjectAirApplication.class, args);
	}

}
