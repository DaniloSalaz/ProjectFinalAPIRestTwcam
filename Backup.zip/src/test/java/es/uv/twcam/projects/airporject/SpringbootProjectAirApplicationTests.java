package es.uv.twcam.projects.airporject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootProjectAirApplicationTests {

	@Test
	void contextLoads() {
	}

}
